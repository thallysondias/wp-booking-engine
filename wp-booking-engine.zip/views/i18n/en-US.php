<?
$adulto = 'Adult';
$crianca = 'Child';
$idade = 'Age';
$code = 'Promo Code';
$guardar = 'Save Information';
$booknow = 'Book Now';
$aviso = 'Book now, at the best price guaranteed';
$local = 'en';
$separador = 'to';
