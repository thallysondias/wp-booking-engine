<?
$adulto = 'Adulto';
$crianca = 'Niño';
$idade = 'Edad';
$code = 'Cod. Promocional';
$guardar = 'Guardar Información';
$booknow = 'Reservar Ahora';
$aviso = 'Reserve ahora, con el mejor precio garantizado';
$local = 'es';
$separador = 'a';
