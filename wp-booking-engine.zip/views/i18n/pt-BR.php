<?php 
$adulto = 'Adulto';
$crianca = 'Criança';
$idade = 'Idade';
$code = 'Cod. Promocional';
$guardar = 'Guardar Informação';
$booknow = 'Reservar Agora';
$aviso = 'Reserve agora, com o melhor preço garantido';
$local = 'pt';
$separador = 'até';
